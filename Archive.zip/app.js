// Use the new modular structure
const VoltTasksApp = require('./src/app');

// Start the application
const app = new VoltTasksApp();
app.start();
