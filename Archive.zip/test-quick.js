const TestBot = require('./src/testBot');

console.log('🧪 Quick Test - New Modular Structure');
console.log('📱 Testing the new modular bot structure with updated keyboard...');

const testBot = new TestBot();
testBot.runTest();
